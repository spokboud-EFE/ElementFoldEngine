
# -*- coding: utf-8 -*-
# Engine round-trip: fit → save → load → infer.
# Why this matters (plain language): a "runtime engine" should be able to
# (1) learn a tiny bit, (2) serialize its knowledge, and (3) reload it to make
# predictions again. This test checks that *pipeline glue* works, not accuracy.
from __future__ import annotations
from pathlib import Path
import torch
import pytest

from elementfold.config import Config
from elementfold.runtime import Engine

def test_engine_save_and_load(tmp_run_dir: Path):
    cfg = Config(
        device="cpu", steps=2, vocab=128, d=32, layers=1, heads=2, seq_len=16,
        fold="none", delta=0.03, capacities=(2, 6, 10, 14), batch=2,
        use_data=False, lang_ckpt=None, vision_ckpt=None, audio_ckpt=None,
        print_every=None,
    )
    eng = Engine(cfg)

    # Fit a couple of synthetic steps — this also *materializes* the model.
    eng.fit(steps=2, out=str(tmp_run_dir))

    # Save a portable engine bundle that includes both weights and Config.
    bundle = tmp_run_dir / "engine.pt"
    eng.save(str(bundle))
    assert bundle.exists(), "Engine.save(...) should write a self-describing bundle."

    # Load a fresh engine from disk and run a tiny inference — shapes should match.
    eng2 = Engine.load(str(bundle), map_location="cpu")
    assert eng2 is not None and eng2.model is not None

    V = getattr(eng2.cfg, "vocab", 128)
    T = getattr(eng2.cfg, "seq_len", 16)
    x = torch.randint(0, V, (1, T), dtype=torch.long)
    out = eng2.infer(x=x, temperature=0.0)  # deterministic greedy path
    # The inference helper returns a dict (tokens, logits, or ledger depending on flags).
    assert isinstance(out, dict), "Runtime.infer(...) should return a structured payload"
    assert "tokens" in out and out["tokens"].shape[-1] == T
