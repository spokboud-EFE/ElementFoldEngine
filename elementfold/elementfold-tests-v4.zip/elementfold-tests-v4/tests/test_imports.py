
# -*- coding: utf-8 -*-
# Sanity check: the public surface should import cleanly for newcomers.
def test_basic_imports():
    import elementfold
    import elementfold.train
    import elementfold.optim
    import elementfold.runtime
    import elementfold.tokenizer
