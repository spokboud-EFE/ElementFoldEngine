
# -*- coding: utf-8 -*-
# Learning-rate schedule: warmup ➜ cosine decay.
# ✿ Intuition: warmup avoids "cold starts"; cosine gives a smooth glide to a
# floor (min_lr_scale ⋅ base_lr). We check monotonic bits and the *math* of the last step.
from __future__ import annotations
import math
import torch
import pytest

def test_scheduler_warmup_then_decay():
    try:
        from elementfold.optim import make_scheduler, get_lr
    except Exception:
        pytest.skip("elementfold.optim not available")
        return

    p = torch.nn.Parameter(torch.zeros(()))
    opt = torch.optim.Adam([p], lr=1e-3)
    warm, total, min_s = 5, 20, 0.1
    sched = make_scheduler(opt, warmup_steps=warm, total_steps=total, min_lr_scale=min_s)

    lrs = []
    for _ in range(total):
        lrs.append(get_lr(opt))
        sched.step()

    # ① Warmup must be non-decreasing
    assert all(lrs[i] <= lrs[i+1] + 1e-12 for i in range(warm-1)), f"Warmup not non-decreasing: {lrs[:warm+1]}"
    # ② After warmup, learning rate should eventually go down
    assert lrs[-1] <= lrs[warm] + 1e-12, f"Final LR should be <= post-warmup LR: {lrs[warm]} -> {lrs[-1]}"
    # ③ Match the expected cosine value at the last (total-1)-th step used by the scheduler
    #    This mirrors elementfold.optim.scale(...) used internally.
    prog = (total - 1 - warm) / max(1, (total - warm))
    expected_scale = min_s + 0.5 * (1.0 - min_s) * (1.0 + math.cos(math.pi * min(1.0, prog)))
    assert abs(lrs[-1] - expected_scale * 1e-3) < 1e-8, f"cosine tail mismatch: got {lrs[-1]:.12f}"
