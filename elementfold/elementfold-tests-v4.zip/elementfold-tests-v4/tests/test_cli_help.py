
# -*- coding: utf-8 -*-
# CLI should present helpful subcommands for newcomers.
from __future__ import annotations
import pytest

def test_cli_help_runs():
    try:
        from elementfold import cli as efcli
    except Exception:
        pytest.skip("CLI not importable")
        return

    # Call the CLI's main() with --help and expect a zero-ish exit.
    rc = efcli.main(["--help"])
    assert rc == 0 or rc is None
