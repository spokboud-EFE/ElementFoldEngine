
# -*- coding: utf-8 -*-
# Config TOML smoke: ensure we can load a tiny config file and instantiate Config.
from __future__ import annotations
from pathlib import Path
import pytest

def test_config_toml_validity():
    try:
        import tomli  # lightweight TOML reader
        from elementfold.config import Config
    except Exception:
        pytest.skip("tomli or elementfold.config unavailable")
        return

    here = Path(__file__).parent
    tiny = here / "configs" / "tiny.toml"
    data = tomli.loads(tiny.read_text())
    cfg = Config(**data)
    # If present, to_kwargs should map to train_loop kw; skip softly if not.
    if hasattr(cfg, "to_kwargs"):
        kw = cfg.to_kwargs()
        for k in ("vocab", "d", "layers", "heads", "seq_len"):
            assert k in kw
