
# -*- coding: utf-8 -*-
# Mini "steering" fit: learns a tiny controller and saves it as a file.
# The interesting part is *wiring*: modules talk to each other and the save path exists.
from __future__ import annotations
from pathlib import Path
import torch
import pytest

def test_fit_steering_and_apply(tmp_run_dir: Path):
    try:
        from elementfold.experience.steering_train import fit_steering
    except Exception:
        pytest.skip("Missing elementfold.experience.steering_train; skipping steering test.")
        return

    save_path = tmp_run_dir / "steering" / "ctrl.pt"
    save_path.parent.mkdir(parents=True, exist_ok=True)  # Ensure the directory exists
    ctrl = fit_steering(steps=40, save_path=str(save_path), device="cpu", print_every=None)
    assert save_path.exists(), "Controller should be written to disk"

    # The controller should clamp inputs into a reasonable range (see control.py).
    u = torch.linspace(-5, 5, 11)
    y = ctrl.apply(u)
    assert torch.all(torch.isfinite(y))
    assert y.min().item() >= -1.0 - 1e-6 and y.max().item() <= 1.0 + 1e-6
