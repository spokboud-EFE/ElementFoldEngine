
# -*- coding: utf-8 -*-
# End-to-end CLI training on synthetic data (2 steps): exercises argument parsing,
# config plumbing, and output file creation without needing any external datasets.
from __future__ import annotations
from pathlib import Path
import pytest

def test_cli_train_tiny(tmp_run_dir: Path):
    try:
        from elementfold import cli as efcli
    except Exception:
        pytest.skip("CLI not importable")
        return

    outdir = tmp_run_dir / "cli_train"
    outdir.mkdir(parents=True, exist_ok=True)
    args = [
        "train",
        "--device", "cpu",
        "--steps", "2",
        "--vocab", "128",
        "--d", "32",
        "--layers", "1",
        "--heads", "2",
        "--seq-len", "16",
        "--fold", "none",
        "--delta", "0.03",
        "--capacities", "2,6,10,14",
        "--batch", "2",
        "--no-data",
        "--out", str(outdir),
        "--print-every", "0",
    ]
    rc = efcli.main(args)
    assert rc == 0 or rc is None

    pt = outdir / "checkpoint.pt"
    assert pt.exists(), "CLI training should write a checkpoint.pt artifact"
