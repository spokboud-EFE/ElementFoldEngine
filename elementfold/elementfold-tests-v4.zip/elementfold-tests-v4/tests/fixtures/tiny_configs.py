
# -*- coding: utf-8 -*-
# Tiny, CPU-friendly shapes for a 1–2 second smoke step.
# We keep numbers small but *valid* for your model: heads divide d, etc.
from __future__ import annotations

def tiny_train_dict(*, device: str = "cpu", steps: int = 8, batch: int = 2) -> dict:
    """
    Return kwargs tailored to elementfold.train.train_loop(...).
    We avoid the dataclass Config to keep the dependency chain short in smoke tests.
    """
    return dict(
        device=device,                 # "cpu" by default; set via env fixture
        steps=steps,                   # tiny training run
        vocab=128,                     # toy vocab
        d=32,                          # model width
        layers=1,                      # depth
        heads=2,                       # attention heads (divides d)
        seq_len=16,                    # context length
        fold="none",                   # keeps the stack light
        delta=0.03,                    # alignment / variational temperature
        capacities=(2, 6, 10, 14),     # the test battery used across the suite
        batch=batch,                   # batch size
        use_data=False,                # synthetic tokens = fast, deterministic
        print_every=None,              # keep pytest logs quiet
    )
