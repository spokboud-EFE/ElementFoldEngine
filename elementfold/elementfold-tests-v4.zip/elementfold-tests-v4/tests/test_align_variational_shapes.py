
# -*- coding: utf-8 -*-
# Alignment head + variational ledger: shapes + finite scalars.
# We *don’t* assume tensors for pos/neg — your code returns Python floats.
from __future__ import annotations
import math
import torch
import pytest

def test_align_and_variational_shapes():
    try:
        from elementfold.align import AlignHead
        from elementfold.variational import VariationalLedger
    except Exception:
        pytest.skip("align/variational modules not present")
        return

    device = torch.device('cpu')
    delta = 0.03
    capacities = torch.tensor([2, 6, 10, 14], device=device)

    align = AlignHead(delta).to(device)
    var = VariationalLedger(delta, (2, 6, 10, 14), tv_weight=0.0).to(device)

    B, T = 8, 32
    X = torch.randn(B, T, device=device)

    loss_align, pos, neg = align(X.mean(dim=1), capacities)
    assert torch.isfinite(loss_align), "align loss must be finite"
    assert loss_align.ndim == 0, "align loss should be a scalar"
    assert isinstance(pos, (float, int)) and isinstance(neg, (float, int)), "pos/neg are Python numbers"
    assert math.isfinite(pos) and math.isfinite(neg), "pos/neg should be finite scalars"

    # Variational ledger produces a scalar penalty; we only smoke-check finiteness.
    loss_var, _ = var(X)
    assert torch.isfinite(loss_var), "variational loss must be finite"
    assert loss_var.ndim == 0
