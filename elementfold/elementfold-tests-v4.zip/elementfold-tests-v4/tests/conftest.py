
# -*- coding: utf-8 -*-
# PyTest glue: small fixtures to keep tests readable.
from __future__ import annotations
from pathlib import Path
import os
import pytest

@pytest.fixture
def device() -> str:
    # Tip: set ELEMENTFOLD_DEVICE=cuda in your shell if you want to exercise CUDA locally.
    return os.environ.get("ELEMENTFOLD_DEVICE", "cpu")

@pytest.fixture
def tmp_run_dir(tmp_path: Path) -> Path:
    # Each test gets its own self-cleaning workspace under /tmp
    runs = tmp_path / "runs"
    runs.mkdir(parents=True, exist_ok=True)
    return runs
