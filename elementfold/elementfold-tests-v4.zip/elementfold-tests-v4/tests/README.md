
# ElementFold – tests v4 (coherent with your repo)

These tests are written to match the APIs actually present in your codebase (as uploaded),
with **gentle, non‑expert comments** that bridge practice ⇄ theory.

**Highlights**

- Smoke‑train on synthetic tokens (`use_data=False`) with tiny shapes so it runs fast.
- Round‑trip the `Engine` via `fit → save → load → infer` (uses your real `Engine` API).
- Learning‑rate warmup → cosine decay checks aligned to your `optim.py` math.
- Alignment / variational heads exercise **finite scalars** even if they’re Python floats.
- Steering controller mini‑fit writes to a real file and clamps outputs.
- Tokenizer round‑trips IDs ⇄ text.

> Unzip this folder into the project (e.g. at `elementfold/elementfold-tests-v4/`) and run `pytest` from your repo root.
