
# -*- coding: utf-8 -*-
# Tokenizer property: encode ⟶ decode round-trips IDs; decoding yields human text.
from __future__ import annotations
import torch
import pytest

def test_tokenizer_encode_decode_roundtrip():
    try:
        from elementfold import tokenizer as tk
    except Exception:
        pytest.skip("Tokenizer not importable")
        return

    text = "hello elementfold!"
    ids = tk.encode(text)
    assert isinstance(ids, list) and all(isinstance(i, int) for i in ids)

    detok = tk.decode(ids)
    # We don’t force exact string equality (normalization may differ), but re-encoding
    # should give back the same id sequence.
    assert tk.encode(detok) == ids
