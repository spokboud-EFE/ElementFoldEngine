
# -*- coding: utf-8 -*-
# 🚦 Smoke-test for the training loop: 8 steps on synthetic tokens.
# Theory link: we only check *existence and finiteness*, not quality —
# the goal is to catch shape/device mismatches early.
from __future__ import annotations
from pathlib import Path
import torch
import pytest

from elementfold.train import train_loop
from .fixtures.tiny_configs import tiny_train_dict

def test_smoke_train(tmp_run_dir: Path, device: str = "cpu"):
    cfg = tiny_train_dict(device=device, steps=8, batch=2)
    # Write an artifact so downstream tests (or humans) can inspect a checkpoint.
    model = train_loop(out=str(tmp_run_dir), **cfg)
    assert isinstance(model, torch.nn.Module)

    # Training writes a PyTorch bundle named 'checkpoint.pt' (by code convention).
    pt = tmp_run_dir / "checkpoint.pt"
    assert pt.exists(), "Expected a lightweight checkpoint for quick manual poking."
